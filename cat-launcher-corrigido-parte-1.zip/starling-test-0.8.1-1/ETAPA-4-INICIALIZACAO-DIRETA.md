# ETAPA 4 - inicialização direta e nome Cat Launcher - NÃO COMPILADO

Sem cargo/NDK neste ambiente: nada abaixo foi compilado ou testado.

## Inicialização
- files_offer.rs: nova const STARTUP_OFFERS = false. Sem o cartão "Keep your files where you can reach
  them" e sem o cartão do Horizon Android ao abrir. O pedido de "todos os arquivos" só aparece quando o
  usuário toca nos botões de pasta (ask_files_offer, options.rs).
- setup/mod.rs: Step::Folder e Step::Horizon só com STARTUP_OFFERS ligado (desligado). Sem tela de login:
  sem perfil, cria o perfil offline "Player" e baixa os arquivos do jogo sozinho (poll_setup, auto_started).
- update_offer.rs: sem aviso de atualização ao abrir (ofereceria o APK do Starling original).

## Nome
- Textos visíveis em Rust, lang en_us/pt_br/ru_ru, diálogos do StarlingActivity.java e tela de boot.
- Mantidos de propósito: id do pacote/JNI (io.github.juanluci.starling), pasta "Starling" no
  armazenamento, linha de créditos "starling.credits.founders", User-Agent, nomes de crates/arquivos.
